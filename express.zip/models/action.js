const mongoose = require('mongoose');

const actionSchema = {
  type: String,
};

module.exports = mongoose.model('actions', actionSchema);
