require('dotenv').config();
const randomColor = require('randomcolor');
const express = require('express');
const io = require('socket.io')();
const mongoose = require('mongoose');
const compression = require('compression');
const app = express();

// express.use(compression());
// might need cookie-session when doing fb login
// var helmet = require('helmet')
// express.use(helmet())
// app.disable('x-powered-by')

// my modules
const config = require('./config/config.js');

const Action = require('./models/action.js');

const socketPort = config.socketPort;
const serverPort = config.serverPort;

mongoose.Promise = global.Promise;
mongoose.connect(
  `${config.dbProtocol}${config.dbUser}:${config.dbPass}@${config.dbHost}:${
    config.dbPort
  }/${config.dbName}`,
  {useMongoClient: true}
);

let players = [];
let rooms = {};

const roomCode = (rooms, id) => {
  let roomCode = '';
  for (const key in rooms) {
    if (rooms[key].includes(id)) {
      roomCode = key;
    }
  }
  return roomCode;
};

app.get('/namecheck/:nickName', function(req, res) {
  let name = req.params.nickName;
  console.log(players.map(itm => itm.name).includes(name));
  if (players.map(itm => itm.name).includes(name)) {
    return res.json({payload: 'name exists'});
  }
  return res.json({payload: 'name available'});
});

app.get('/health', (req, res) => {
  console.log('hi');
  return res.status(200).send('health route working');
});

io.on('connection', client => {
  players = [
    ...players,
    {
      id: client.id,
      name: '',
      color: randomColor({luminosity: 'bright'}),
      currentAnswer: '',
      readyCheck: false,
      round: 0,
      roomCode: ''
    }
  ];
  client.emit('id', client.id);
  // emit state
  client.on('joinLobby', joinData => {
    console.log(joinData.roomCode);
    rooms = {
      ...rooms,
      [joinData.roomCode]: rooms[joinData.roomCode]
        ? [...rooms[joinData.roomCode], client.id]
        : [client.id]
    };

    players = players.map(
      itm =>
        itm.id === client.id
          ? {...itm, name: joinData.name, roomCode: joinData.roomCode}
          : itm
    );
    client.join(joinData.roomCode);
    io
      .to(joinData.roomCode)
      .emit(
        'players',
        players.filter(itm => itm.roomCode === joinData.roomCode)
      );
  });

  client.on('sharedAction', action => {
    client.to(roomCode(rooms, client.id)).emit('sharedAction', action);
    // action.save;
  });

  client.on('singleAction', remoteRoundData => {
    // action.save;
  });

  client.on('disconnect', () => {
    const clientIndex = players.findIndex(itm => itm.id === client.id);
    const currentRoom = roomCode(rooms, client.id);
    players = [
      ...players.slice(0, clientIndex),
      ...players.slice(clientIndex + 1)
    ];
    client
      .to(currentRoom)
      .emit('players', players.filter(itm => itm.roomCode === currentRoom));
  });
});

io.listen(socketPort);
console.log('listening on port ', socketPort);
app.listen(serverPort);
console.log('listening on port ', serverPort);
