const config = {
  dbProtocol: process.env.DB_PROTOCOL,
  dbHost: process.env.DB_HOST,
  dbPort: process.env.DB_PORT,
  dbName: process.env.DB_NAME,
  dbUser: process.env.DB_USER,
  dbPass: process.env.DB_PASS,
  socketPort: process.env.SOCKET_PORT,
  serverPort: process.env.SERVER_PORT
};

module.exports = config;
